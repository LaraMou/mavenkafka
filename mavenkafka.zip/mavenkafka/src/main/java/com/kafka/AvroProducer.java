package com.kafka;

public class AvroProducer {
}
